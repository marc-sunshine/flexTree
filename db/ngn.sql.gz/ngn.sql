-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 12, 2011 at 03:43 
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ngn`
--

-- --------------------------------------------------------

--
-- Table structure for table `trees`
--

CREATE TABLE IF NOT EXISTS `trees` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `trees`
--

INSERT INTO `trees` (`ID`, `name`) VALUES
(1, 'main');

-- --------------------------------------------------------

--
-- Table structure for table `tree_nodes`
--

CREATE TABLE IF NOT EXISTS `tree_nodes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `treeId` int(11) NOT NULL,
  `parentId` int(11) NOT NULL,
  `nodeType` int(11) NOT NULL,
  `nodePosition` int(11) NOT NULL,
  `nodeName` varchar(30) NOT NULL,
  `nodeValue` varchar(30) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `nodeName` (`nodeName`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `tree_nodes`
--

INSERT INTO `tree_nodes` (`Id`, `treeId`, `parentId`, `nodeType`, `nodePosition`, `nodeName`, `nodeValue`) VALUES
(2, 1, 0, 2, 0, 'Admin', '/admin/tree/'),
(4, 1, 2, 2, 0, 'New Node', '/admin/newtreenode/'),
(19, 1, 0, 1, 1, 'First Page 2', 'test\r\ntest2'),
(22, 1, 19, 1, 0, 'Page 4', '');
